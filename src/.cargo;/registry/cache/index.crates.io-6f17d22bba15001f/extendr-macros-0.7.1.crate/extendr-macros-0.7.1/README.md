# extendr-macros

A procedural macro crate for extendr-api.

This crate implements macros such as the `#[extendr]` function
markup and the `extendr_module!` macro. See `extendr-api` for
more details.
