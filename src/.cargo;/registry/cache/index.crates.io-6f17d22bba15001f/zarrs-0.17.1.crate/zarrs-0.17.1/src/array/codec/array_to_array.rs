//! Array to array codecs.

#[cfg(feature = "bitround")]
pub mod bitround;
#[cfg(feature = "transpose")]
pub mod transpose;
