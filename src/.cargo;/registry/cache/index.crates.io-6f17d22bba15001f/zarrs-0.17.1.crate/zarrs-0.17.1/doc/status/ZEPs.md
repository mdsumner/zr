| [Zarr Enhancement Proposal]             | Status                     | Zarrs        |
| --------------------------------------- | -------------------------- | ------------ |
| [ZEP0001]: Zarr specification version 3 | Accepted                   | Full support |
| [ZEP0002]: Sharding codec               | Accepted                   | Full support |
| Draft [ZEP0003]: Variable chunking      | [zarr-developers #52]      | Full support |
| Draft ZEP0007: Strings                  | [zarr-developers/zeps #47] | Prototype    |

[Zarr Enhancement Proposal]: https://zarr.dev/zeps/
[ZEP0001]: https://zarr.dev/zeps/accepted/ZEP0001.html
[ZEP0002]: https://zarr.dev/zeps/accepted/ZEP0002.html
[ZEP0003]: https://zarr.dev/zeps/draft/ZEP0003.html

[zarr-developers #52]: https://github.com/orgs/zarr-developers/discussions/52
[zarr-developers/zeps #47]: https://github.com/zarr-developers/zeps/pull/47#issuecomment-1710505141
