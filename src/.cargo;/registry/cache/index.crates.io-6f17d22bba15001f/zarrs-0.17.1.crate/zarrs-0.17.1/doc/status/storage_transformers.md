Zarr V3 does not currently define any storage transformers.
