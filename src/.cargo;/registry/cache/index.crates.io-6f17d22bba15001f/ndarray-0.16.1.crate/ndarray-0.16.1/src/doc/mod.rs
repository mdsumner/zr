//! Standalone documentation pages.

pub mod crate_feature_flags;
pub mod ndarray_for_numpy_users;
