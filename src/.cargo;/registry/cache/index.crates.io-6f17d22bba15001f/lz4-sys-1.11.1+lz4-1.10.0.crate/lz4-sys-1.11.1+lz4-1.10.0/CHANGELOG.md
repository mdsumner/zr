1.10.0:
 * No change to lz4-sys crate

1.9.5:
 * expand Lz4FrameInfo struct

1.7.5:

 * Change version number

1.0.1+1.7.5:

 * Update lz4 to v1.7.5 #18 (thanks to Roguelazer)

1.0.1+1.7.3:

 * Split out separate sys package #16 (thanks to Thijs Cadier)
