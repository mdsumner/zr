pub(crate) type Clock = quanta::Clock;
pub(crate) type Instant = quanta::Instant;

#[cfg(test)]
pub(crate) type Mock = quanta::Mock;
